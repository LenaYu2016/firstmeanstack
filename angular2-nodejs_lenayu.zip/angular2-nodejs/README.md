# Angular 2 + NodeJS
This repository holds the code for my Angular 2 + NodeJS video(s) on YouTube

# Usage

`npm install`

`npm run gulp` (starts gulp for compilation, separate terminal/ command line window)

`npm start` (starts NodeJS server, separate terminal/ command line window)