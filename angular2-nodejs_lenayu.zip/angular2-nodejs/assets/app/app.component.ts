import { Component } from '@angular/core';
import {User} from './user.model';
import {OnInit} from '@angular/core';
import {ControlGroup} from '@angular/common';
import {UserService} from './user.service';
import {AuthService} from './auth.service';
import {tokenNotExpired,JwtHelper} from 'angular2-jwt';
declare var Auth0Lock;
@Component({
    moduleId: module.id,
    selector: 'my-app',
    templateUrl: 'app.template.html',
    providers:[UserService]
  })
export class AppComponent{
    lock=new Auth0Lock('bi0pqd4efYzvC1T7ff22hEeruJC9WPsL','lenayu2016.auth0.com');
    jwtHelper:JwtHelper=new JwtHelper();
    users:User[]=[];
    adduser:User=new User(null,null,null);
    validEmail=true;
    used=false;
    show=false;
    constructor(private userservice:UserService){

    }
    onSubmit(){
        this.userservice.save(this.adduser).subscribe(info=> {
                console.log(info);
            },
                error=> {
                console.log(error);
            },
            ()=>{
                this.users.push(this.adduser);
            });
    }
    ngOnInit(){
        this.userservice.find().subscribe(info=> {
                var users=this.users;
                info.forEach(function(item,index){
                    var x=new User(item.FirstName,item.LastName,item.Email);
                    users.push(x);
                });
            },
                error=> {
                console.log(error);
            },
            ()=>{

            });


    }
    validateEmail(email){
        var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

        if (!filter.test(email)) {
            this.validEmail=false;
        }else {
            this.validEmail = true;
            this.usedemail(email);
        }
    }
    usedemail(email){
        var flag;
        this.users.forEach(function(item,index){

            if(email==item.Email){
                flag=true;

            }
        });
        if(flag){
            this.used=true;
        }else{
            this.used=false;
        }

    }
    toggleList(){
        this.show=(!this.show);
    }
  login(){
this.lock.show((err:string,profile:String,id_token:string)=>{
    if(err){
        throw new Error(err);
    }
    localStorage.setItem('profile',JSON.stringify(profile));
    localStorage.setItem('id_token',JSON.stringify(id_token));
        this.LoggedIn();
}

);
  }
    logout(){
localStorage.removeItem('profile');
        localStorage.removeItem('id_token');
        this.LoggedIn();

    }
    LoggedIn(){
return tokenNotExpired();
    }
}