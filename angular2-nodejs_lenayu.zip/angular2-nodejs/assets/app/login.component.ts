import { Component } from '@angular/core';
import {User} from './user.model';
import {OnInit} from '@angular/core';
import {ControlGroup} from '@angular/common';
import {UserService} from './user.service';
import {AuthService} from './auth.service';
@Component({
    moduleId: module.id,
    selector: 'my-app',
    templateUrl: 'app.template.html',
    providers:[UserService]})
export class LoginComponent implements OnInit {
    users:User[] = [];
    adduser:User = new User(null, null, null);
    validEmail = true;
    used = false;
    show = false;

    constructor(private userservice:UserService) {

    }
}