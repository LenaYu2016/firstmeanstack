import {Component} from '@angular/core';
@Component({
    moduleId: module.id,
    selector: 'my-app',
    template:`<h3>Please login first</h3>`
})
export class PublicComponent implements OnInit{


}