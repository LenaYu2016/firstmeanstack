export class User{
    constructor(public FirstName:string,public LastName:string,public Email:string){}
}