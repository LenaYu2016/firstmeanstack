import {User} from './user.model';
import {Injectable,ViewContainerRef} from '@angular/core';
import {Http,Headers,RequestOptions} from '@angular/http';
import {Observable} from 'rxjs/Observable';
import 'rxjs/Rx';
import 'rxjs/add/operator/map';
@Injectable()
export class UserService{
   constructor(private http:Http){

   }
   save(user:User){
       console.log(user);
     const body=JSON.stringify(user);
      const header=new Headers({'Content-Type':'application/json'});
       let options = new RequestOptions({ headers: header });
     return this.http.post('http://localhost:3000/user',body,options).map(res=>res.json());
   }
    find(){


        const header=new Headers({'Content-Type':'application/json'});
        let options = new RequestOptions({ headers: header });
        return this.http.get('http://localhost:3000/all',options).map(res=>res.json());
    }
}