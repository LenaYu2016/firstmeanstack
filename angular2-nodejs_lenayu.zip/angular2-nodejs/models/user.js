var mongoose=require('mongoose');
var Schema=mongoose.Schema;
var mongooseUniqueValidator=require('mongoose-unique-validator');
var schema=new Schema({
    FirstName:{type:String,required:true},
    LastName:{type:String,required:true},
    Email:{type:String,required:true,unique:true}
});
schema.plugin(mongooseUniqueValidator);
module.exports=mongoose.model('users',schema);