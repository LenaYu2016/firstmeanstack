"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var user_model_1 = require('./user.model');
var user_service_1 = require('./user.service');
var angular2_jwt_1 = require('angular2-jwt');
var AppComponent = (function () {
    function AppComponent(userservice) {
        this.userservice = userservice;
        this.lock = new Auth0Lock('bi0pqd4efYzvC1T7ff22hEeruJC9WPsL', 'lenayu2016.auth0.com');
        this.jwtHelper = new angular2_jwt_1.JwtHelper();
        this.users = [];
        this.adduser = new user_model_1.User(null, null, null);
        this.validEmail = true;
        this.used = false;
        this.show = false;
    }
    AppComponent.prototype.onSubmit = function () {
        var _this = this;
        this.userservice.save(this.adduser).subscribe(function (info) {
            console.log(info);
        }, function (error) {
            console.log(error);
        }, function () {
            _this.users.push(_this.adduser);
        });
    };
    AppComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.userservice.find().subscribe(function (info) {
            var users = _this.users;
            info.forEach(function (item, index) {
                var x = new user_model_1.User(item.FirstName, item.LastName, item.Email);
                users.push(x);
            });
        }, function (error) {
            console.log(error);
        }, function () {
        });
    };
    AppComponent.prototype.validateEmail = function (email) {
        var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        if (!filter.test(email)) {
            this.validEmail = false;
        }
        else {
            this.validEmail = true;
            this.usedemail(email);
        }
    };
    AppComponent.prototype.usedemail = function (email) {
        var flag;
        this.users.forEach(function (item, index) {
            if (email == item.Email) {
                flag = true;
            }
        });
        if (flag) {
            this.used = true;
        }
        else {
            this.used = false;
        }
    };
    AppComponent.prototype.toggleList = function () {
        this.show = (!this.show);
    };
    AppComponent.prototype.login = function () {
        var _this = this;
        this.lock.show(function (err, profile, id_token) {
            if (err) {
                throw new Error(err);
            }
            localStorage.setItem('profile', JSON.stringify(profile));
            localStorage.setItem('id_token', JSON.stringify(id_token));
            _this.LoggedIn();
        });
    };
    AppComponent.prototype.logout = function () {
        localStorage.removeItem('profile');
        localStorage.removeItem('id_token');
        this.LoggedIn();
    };
    AppComponent.prototype.LoggedIn = function () {
        return angular2_jwt_1.tokenNotExpired();
    };
    AppComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'my-app',
            templateUrl: 'app.template.html',
            providers: [user_service_1.UserService]
        }), 
        __metadata('design:paramtypes', [user_service_1.UserService])
    ], AppComponent);
    return AppComponent;
}());
exports.AppComponent = AppComponent;

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwcC5jb21wb25lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQUFBLHFCQUEwQixlQUFlLENBQUMsQ0FBQTtBQUMxQywyQkFBbUIsY0FBYyxDQUFDLENBQUE7QUFHbEMsNkJBQTBCLGdCQUFnQixDQUFDLENBQUE7QUFFM0MsNkJBQXdDLGNBQWMsQ0FBQyxDQUFBO0FBUXZEO0lBUUksc0JBQW9CLFdBQXVCO1FBQXZCLGdCQUFXLEdBQVgsV0FBVyxDQUFZO1FBUDNDLFNBQUksR0FBQyxJQUFJLFNBQVMsQ0FBQyxrQ0FBa0MsRUFBQyxzQkFBc0IsQ0FBQyxDQUFDO1FBQzlFLGNBQVMsR0FBVyxJQUFJLHdCQUFTLEVBQUUsQ0FBQztRQUNwQyxVQUFLLEdBQVEsRUFBRSxDQUFDO1FBQ2hCLFlBQU8sR0FBTSxJQUFJLGlCQUFJLENBQUMsSUFBSSxFQUFDLElBQUksRUFBQyxJQUFJLENBQUMsQ0FBQztRQUN0QyxlQUFVLEdBQUMsSUFBSSxDQUFDO1FBQ2hCLFNBQUksR0FBQyxLQUFLLENBQUM7UUFDWCxTQUFJLEdBQUMsS0FBSyxDQUFDO0lBR1gsQ0FBQztJQUNELCtCQUFRLEdBQVI7UUFBQSxpQkFVQztRQVRHLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxJQUFJO1lBQzFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDdEIsQ0FBQyxFQUNHLFVBQUEsS0FBSztZQUNMLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDdkIsQ0FBQyxFQUNEO1lBQ0ksS0FBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsS0FBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ2xDLENBQUMsQ0FBQyxDQUFDO0lBQ1gsQ0FBQztJQUNELCtCQUFRLEdBQVI7UUFBQSxpQkFnQkM7UUFmRyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksRUFBRSxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7WUFDOUIsSUFBSSxLQUFLLEdBQUMsS0FBSSxDQUFDLEtBQUssQ0FBQztZQUNyQixJQUFJLENBQUMsT0FBTyxDQUFDLFVBQVMsSUFBSSxFQUFDLEtBQUs7Z0JBQzVCLElBQUksQ0FBQyxHQUFDLElBQUksaUJBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFDLElBQUksQ0FBQyxRQUFRLEVBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUN4RCxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ2xCLENBQUMsQ0FBQyxDQUFDO1FBQ1AsQ0FBQyxFQUNHLFVBQUEsS0FBSztZQUNMLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDdkIsQ0FBQyxFQUNEO1FBRUEsQ0FBQyxDQUFDLENBQUM7SUFHWCxDQUFDO0lBQ0Qsb0NBQWEsR0FBYixVQUFjLEtBQUs7UUFDZixJQUFJLE1BQU0sR0FBRyxpRUFBaUUsQ0FBQztRQUUvRSxFQUFFLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3RCLElBQUksQ0FBQyxVQUFVLEdBQUMsS0FBSyxDQUFDO1FBQzFCLENBQUM7UUFBQSxJQUFJLENBQUMsQ0FBQztZQUNILElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDO1lBQ3ZCLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDMUIsQ0FBQztJQUNMLENBQUM7SUFDRCxnQ0FBUyxHQUFULFVBQVUsS0FBSztRQUNYLElBQUksSUFBSSxDQUFDO1FBQ1QsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsVUFBUyxJQUFJLEVBQUMsS0FBSztZQUVsQyxFQUFFLENBQUEsQ0FBQyxLQUFLLElBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFBLENBQUM7Z0JBQ2xCLElBQUksR0FBQyxJQUFJLENBQUM7WUFFZCxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7UUFDSCxFQUFFLENBQUEsQ0FBQyxJQUFJLENBQUMsQ0FBQSxDQUFDO1lBQ0wsSUFBSSxDQUFDLElBQUksR0FBQyxJQUFJLENBQUM7UUFDbkIsQ0FBQztRQUFBLElBQUksQ0FBQSxDQUFDO1lBQ0YsSUFBSSxDQUFDLElBQUksR0FBQyxLQUFLLENBQUM7UUFDcEIsQ0FBQztJQUVMLENBQUM7SUFDRCxpQ0FBVSxHQUFWO1FBQ0ksSUFBSSxDQUFDLElBQUksR0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQzNCLENBQUM7SUFDSCw0QkFBSyxHQUFMO1FBQUEsaUJBV0M7UUFWSCxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFDLEdBQVUsRUFBQyxPQUFjLEVBQUMsUUFBZTtZQUNyRCxFQUFFLENBQUEsQ0FBQyxHQUFHLENBQUMsQ0FBQSxDQUFDO2dCQUNKLE1BQU0sSUFBSSxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDekIsQ0FBQztZQUNELFlBQVksQ0FBQyxPQUFPLENBQUMsU0FBUyxFQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztZQUN4RCxZQUFZLENBQUMsT0FBTyxDQUFDLFVBQVUsRUFBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7WUFDdEQsS0FBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQ3hCLENBQUMsQ0FFQSxDQUFDO0lBQ0EsQ0FBQztJQUNDLDZCQUFNLEdBQU47UUFDSixZQUFZLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQzNCLFlBQVksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDcEMsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO0lBRXBCLENBQUM7SUFDRCwrQkFBUSxHQUFSO1FBQ0osTUFBTSxDQUFDLDhCQUFlLEVBQUUsQ0FBQztJQUNyQixDQUFDO0lBOUZMO1FBQUMsZ0JBQVMsQ0FBQztZQUNQLFFBQVEsRUFBRSxNQUFNLENBQUMsRUFBRTtZQUNuQixRQUFRLEVBQUUsUUFBUTtZQUNsQixXQUFXLEVBQUUsbUJBQW1CO1lBQ2hDLFNBQVMsRUFBQyxDQUFDLDBCQUFXLENBQUM7U0FDeEIsQ0FBQzs7b0JBQUE7SUEwRkosbUJBQUM7QUFBRCxDQXpGQSxBQXlGQyxJQUFBO0FBekZZLG9CQUFZLGVBeUZ4QixDQUFBIiwiZmlsZSI6ImFwcC5jb21wb25lbnQuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHtVc2VyfSBmcm9tICcuL3VzZXIubW9kZWwnO1xyXG5pbXBvcnQge09uSW5pdH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7Q29udHJvbEdyb3VwfSBmcm9tICdAYW5ndWxhci9jb21tb24nO1xyXG5pbXBvcnQge1VzZXJTZXJ2aWNlfSBmcm9tICcuL3VzZXIuc2VydmljZSc7XHJcbmltcG9ydCB7QXV0aFNlcnZpY2V9IGZyb20gJy4vYXV0aC5zZXJ2aWNlJztcclxuaW1wb3J0IHt0b2tlbk5vdEV4cGlyZWQsSnd0SGVscGVyfSBmcm9tICdhbmd1bGFyMi1qd3QnO1xyXG5kZWNsYXJlIHZhciBBdXRoMExvY2s7XHJcbkBDb21wb25lbnQoe1xyXG4gICAgbW9kdWxlSWQ6IG1vZHVsZS5pZCxcclxuICAgIHNlbGVjdG9yOiAnbXktYXBwJyxcclxuICAgIHRlbXBsYXRlVXJsOiAnYXBwLnRlbXBsYXRlLmh0bWwnLFxyXG4gICAgcHJvdmlkZXJzOltVc2VyU2VydmljZV1cclxuICB9KVxyXG5leHBvcnQgY2xhc3MgQXBwQ29tcG9uZW50e1xyXG4gICAgbG9jaz1uZXcgQXV0aDBMb2NrKCdiaTBwcWQ0ZWZZenZDMVQ3ZmYyMmhFZXJ1SkM5V1BzTCcsJ2xlbmF5dTIwMTYuYXV0aDAuY29tJyk7XHJcbiAgICBqd3RIZWxwZXI6Snd0SGVscGVyPW5ldyBKd3RIZWxwZXIoKTtcclxuICAgIHVzZXJzOlVzZXJbXT1bXTtcclxuICAgIGFkZHVzZXI6VXNlcj1uZXcgVXNlcihudWxsLG51bGwsbnVsbCk7XHJcbiAgICB2YWxpZEVtYWlsPXRydWU7XHJcbiAgICB1c2VkPWZhbHNlO1xyXG4gICAgc2hvdz1mYWxzZTtcclxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgdXNlcnNlcnZpY2U6VXNlclNlcnZpY2Upe1xyXG5cclxuICAgIH1cclxuICAgIG9uU3VibWl0KCl7XHJcbiAgICAgICAgdGhpcy51c2Vyc2VydmljZS5zYXZlKHRoaXMuYWRkdXNlcikuc3Vic2NyaWJlKGluZm89PiB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhpbmZvKTtcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIGVycm9yPT4ge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAoKT0+e1xyXG4gICAgICAgICAgICAgICAgdGhpcy51c2Vycy5wdXNoKHRoaXMuYWRkdXNlcik7XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgfVxyXG4gICAgbmdPbkluaXQoKXtcclxuICAgICAgICB0aGlzLnVzZXJzZXJ2aWNlLmZpbmQoKS5zdWJzY3JpYmUoaW5mbz0+IHtcclxuICAgICAgICAgICAgICAgIHZhciB1c2Vycz10aGlzLnVzZXJzO1xyXG4gICAgICAgICAgICAgICAgaW5mby5mb3JFYWNoKGZ1bmN0aW9uKGl0ZW0saW5kZXgpe1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciB4PW5ldyBVc2VyKGl0ZW0uRmlyc3ROYW1lLGl0ZW0uTGFzdE5hbWUsaXRlbS5FbWFpbCk7XHJcbiAgICAgICAgICAgICAgICAgICAgdXNlcnMucHVzaCh4KTtcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICgpPT57XHJcblxyXG4gICAgICAgICAgICB9KTtcclxuXHJcblxyXG4gICAgfVxyXG4gICAgdmFsaWRhdGVFbWFpbChlbWFpbCl7XHJcbiAgICAgICAgdmFyIGZpbHRlciA9IC9eKFthLXpBLVowLTlfXFwuXFwtXSkrXFxAKChbYS16QS1aMC05XFwtXSkrXFwuKSsoW2EtekEtWjAtOV17Miw0fSkrJC87XHJcblxyXG4gICAgICAgIGlmICghZmlsdGVyLnRlc3QoZW1haWwpKSB7XHJcbiAgICAgICAgICAgIHRoaXMudmFsaWRFbWFpbD1mYWxzZTtcclxuICAgICAgICB9ZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMudmFsaWRFbWFpbCA9IHRydWU7XHJcbiAgICAgICAgICAgIHRoaXMudXNlZGVtYWlsKGVtYWlsKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICB1c2VkZW1haWwoZW1haWwpe1xyXG4gICAgICAgIHZhciBmbGFnO1xyXG4gICAgICAgIHRoaXMudXNlcnMuZm9yRWFjaChmdW5jdGlvbihpdGVtLGluZGV4KXtcclxuXHJcbiAgICAgICAgICAgIGlmKGVtYWlsPT1pdGVtLkVtYWlsKXtcclxuICAgICAgICAgICAgICAgIGZsYWc9dHJ1ZTtcclxuXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgICAgICBpZihmbGFnKXtcclxuICAgICAgICAgICAgdGhpcy51c2VkPXRydWU7XHJcbiAgICAgICAgfWVsc2V7XHJcbiAgICAgICAgICAgIHRoaXMudXNlZD1mYWxzZTtcclxuICAgICAgICB9XHJcblxyXG4gICAgfVxyXG4gICAgdG9nZ2xlTGlzdCgpe1xyXG4gICAgICAgIHRoaXMuc2hvdz0oIXRoaXMuc2hvdyk7XHJcbiAgICB9XHJcbiAgbG9naW4oKXtcclxudGhpcy5sb2NrLnNob3coKGVycjpzdHJpbmcscHJvZmlsZTpTdHJpbmcsaWRfdG9rZW46c3RyaW5nKT0+e1xyXG4gICAgaWYoZXJyKXtcclxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoZXJyKTtcclxuICAgIH1cclxuICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKCdwcm9maWxlJyxKU09OLnN0cmluZ2lmeShwcm9maWxlKSk7XHJcbiAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSgnaWRfdG9rZW4nLEpTT04uc3RyaW5naWZ5KGlkX3Rva2VuKSk7XHJcbiAgICAgICAgdGhpcy5Mb2dnZWRJbigpO1xyXG59XHJcblxyXG4pO1xyXG4gIH1cclxuICAgIGxvZ291dCgpe1xyXG5sb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbSgncHJvZmlsZScpO1xyXG4gICAgICAgIGxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKCdpZF90b2tlbicpO1xyXG4gICAgICAgIHRoaXMuTG9nZ2VkSW4oKTtcclxuXHJcbiAgICB9XHJcbiAgICBMb2dnZWRJbigpe1xyXG5yZXR1cm4gdG9rZW5Ob3RFeHBpcmVkKCk7XHJcbiAgICB9XHJcbn0iXSwic291cmNlUm9vdCI6Ii9zb3VyY2UvIn0=
