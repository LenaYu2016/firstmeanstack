"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var angular2_jwt_1 = require('angular2-jwt/angular2-jwt');
daclare;
var Auth0Lock;
var AppComponent = (function () {
    function AppComponent() {
        this.lock = new Auth0Lock('bi0pqd4efYzvC1T7ff22hEeruJC9WPsL', 'lenayu2016.auth0.com');
        this.jwtHelper = new angular2_jwt_1.JwtHelper();
    }
    AppComponent.prototype.login = function () {
        var _this = this;
        this.lock.show(function (err, profile, id_token) {
            if (err) {
                throw new Error(err);
            }
            localStorage.setItem('profile', JSON.stringify(profile));
            localStorage.setItem('id_token', JSON.stringify(id_token));
            _this.LoggedIn();
        });
    };
    AppComponent.prototype.logout = function () {
        localStorage.removeItem('profile');
        localStorage.removeItem('id_token');
        this.LoggedIn();
    };
    AppComponent.prototype.LoggedIn = function () {
        return angular2_jwt_1.tokenNotExpired();
    };
    AppComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'my-app',
            template: "<div><nav class=\"nav nav-tabs\">\n<li role=\"presentation\" class=\"active\" [routerLink]=\"['/']\"><a href=\"#\">Public</a></li>\n  <li role=\"presentation\" *ngIf=\"!LoggedIn()\" (click)=\"login()\"><a href=\"#\">Login</a></li>\n  <li role=\"presentation\"  *ngIf=\"LoggedIn()\" (click)=\"logout()\"><a href=\"#\">Logout</a></li>\n    </nav></div><router-outlet></router-outlet>"
        }), 
        __metadata('design:paramtypes', [])
    ], AppComponent);
    return AppComponent;
}());
exports.AppComponent = AppComponent;

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwcC5jb21wb25lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQUFBLHFCQUEwQixlQUFlLENBQUMsQ0FBQTtBQU0xQyw2QkFBd0MsMkJBQTJCLENBQUMsQ0FBQTtBQUNwRSxPQUFPLENBQUE7QUFBQyxJQUFJLFNBQVMsQ0FBQztBQVV0QjtJQUFBO1FBQ0ksU0FBSSxHQUFDLElBQUksU0FBUyxDQUFDLGtDQUFrQyxFQUFDLHNCQUFzQixDQUFDLENBQUM7UUFDOUUsY0FBUyxHQUFXLElBQUksd0JBQVMsRUFBRSxDQUFDO0lBc0J4QyxDQUFDO0lBckJDLDRCQUFLLEdBQUw7UUFBQSxpQkFXQztRQVZILElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQUMsR0FBVSxFQUFDLE9BQWMsRUFBQyxRQUFlO1lBQ3JELEVBQUUsQ0FBQSxDQUFDLEdBQUcsQ0FBQyxDQUFBLENBQUM7Z0JBQ0osTUFBTSxJQUFJLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUN6QixDQUFDO1lBQ0QsWUFBWSxDQUFDLE9BQU8sQ0FBQyxTQUFTLEVBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO1lBQ3hELFlBQVksQ0FBQyxPQUFPLENBQUMsVUFBVSxFQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztZQUN0RCxLQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDeEIsQ0FBQyxDQUVBLENBQUM7SUFDQSxDQUFDO0lBQ0MsNkJBQU0sR0FBTjtRQUNKLFlBQVksQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDM0IsWUFBWSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUNwQyxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7SUFFcEIsQ0FBQztJQUNELCtCQUFRLEdBQVI7UUFDSixNQUFNLENBQUMsOEJBQWUsRUFBRSxDQUFDO0lBQ3JCLENBQUM7SUFoQ0w7UUFBQyxnQkFBUyxDQUFDO1lBQ1AsUUFBUSxFQUFFLE1BQU0sQ0FBQyxFQUFFO1lBQ25CLFFBQVEsRUFBRSxRQUFRO1lBQ2xCLFFBQVEsRUFBQywrWEFJbUM7U0FDN0MsQ0FBQzs7b0JBQUE7SUF5QkosbUJBQUM7QUFBRCxDQXhCQSxBQXdCQyxJQUFBO0FBeEJZLG9CQUFZLGVBd0J4QixDQUFBIiwiZmlsZSI6ImFzc2V0cy9hcHAvYXBwLmNvbXBvbmVudC5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQge1VzZXJ9IGZyb20gJy4vdXNlci5tb2RlbCc7XHJcbmltcG9ydCB7T25Jbml0fSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHtDb250cm9sR3JvdXB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbic7XHJcbmltcG9ydCB7VXNlclNlcnZpY2V9IGZyb20gJy4vdXNlci5zZXJ2aWNlJztcclxuaW1wb3J0IHtBdXRoU2VydmljZX0gZnJvbSAnLi9hdXRoLnNlcnZpY2UnO1xyXG5pbXBvcnQge3Rva2VuTm90RXhwaXJlZCxKd3RIZWxwZXJ9IGZyb20gJ2FuZ3VsYXIyLWp3dC9hbmd1bGFyMi1qd3QnO1xyXG5kYWNsYXJlIHZhciBBdXRoMExvY2s7XHJcbkBDb21wb25lbnQoe1xyXG4gICAgbW9kdWxlSWQ6IG1vZHVsZS5pZCxcclxuICAgIHNlbGVjdG9yOiAnbXktYXBwJyxcclxuICAgIHRlbXBsYXRlOmA8ZGl2PjxuYXYgY2xhc3M9XCJuYXYgbmF2LXRhYnNcIj5cclxuPGxpIHJvbGU9XCJwcmVzZW50YXRpb25cIiBjbGFzcz1cImFjdGl2ZVwiIFtyb3V0ZXJMaW5rXT1cIlsnLyddXCI+PGEgaHJlZj1cIiNcIj5QdWJsaWM8L2E+PC9saT5cclxuICA8bGkgcm9sZT1cInByZXNlbnRhdGlvblwiICpuZ0lmPVwiIUxvZ2dlZEluKClcIiAoY2xpY2spPVwibG9naW4oKVwiPjxhIGhyZWY9XCIjXCI+TG9naW48L2E+PC9saT5cclxuICA8bGkgcm9sZT1cInByZXNlbnRhdGlvblwiICAqbmdJZj1cIkxvZ2dlZEluKClcIiAoY2xpY2spPVwibG9nb3V0KClcIj48YSBocmVmPVwiI1wiPkxvZ291dDwvYT48L2xpPlxyXG4gICAgPC9uYXY+PC9kaXY+PHJvdXRlci1vdXRsZXQ+PC9yb3V0ZXItb3V0bGV0PmBcclxuICB9KVxyXG5leHBvcnQgY2xhc3MgQXBwQ29tcG9uZW50e1xyXG4gICAgbG9jaz1uZXcgQXV0aDBMb2NrKCdiaTBwcWQ0ZWZZenZDMVQ3ZmYyMmhFZXJ1SkM5V1BzTCcsJ2xlbmF5dTIwMTYuYXV0aDAuY29tJyk7XHJcbiAgICBqd3RIZWxwZXI6Snd0SGVscGVyPW5ldyBKd3RIZWxwZXIoKTtcclxuICBsb2dpbigpe1xyXG50aGlzLmxvY2suc2hvdygoZXJyOnN0cmluZyxwcm9maWxlOlN0cmluZyxpZF90b2tlbjpzdHJpbmcpPT57XHJcbiAgICBpZihlcnIpe1xyXG4gICAgICAgIHRocm93IG5ldyBFcnJvcihlcnIpO1xyXG4gICAgfVxyXG4gICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ3Byb2ZpbGUnLEpTT04uc3RyaW5naWZ5KHByb2ZpbGUpKTtcclxuICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKCdpZF90b2tlbicsSlNPTi5zdHJpbmdpZnkoaWRfdG9rZW4pKTtcclxuICAgICAgICB0aGlzLkxvZ2dlZEluKCk7XHJcbn1cclxuXHJcbik7XHJcbiAgfVxyXG4gICAgbG9nb3V0KCl7XHJcbmxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKCdwcm9maWxlJyk7XHJcbiAgICAgICAgbG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0oJ2lkX3Rva2VuJyk7XHJcbiAgICAgICAgdGhpcy5Mb2dnZWRJbigpO1xyXG5cclxuICAgIH1cclxuICAgIExvZ2dlZEluKCl7XHJcbnJldHVybiB0b2tlbk5vdEV4cGlyZWQoKTtcclxuICAgIH1cclxufSJdLCJzb3VyY2VSb290IjoiL3NvdXJjZS8ifQ==
