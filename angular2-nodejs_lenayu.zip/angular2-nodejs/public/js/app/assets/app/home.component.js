"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var user_model_1 = require('./user.model');
var user_service_1 = require('./user.service');
var HomeComponent = (function () {
    function HomeComponent(userservice) {
        this.userservice = userservice;
        this.users = [];
        this.adduser = new user_model_1.User(null, null, null);
        this.validEmail = true;
        this.used = false;
        this.show = false;
    }
    HomeComponent.prototype.onSubmit = function () {
        var _this = this;
        this.userservice.save(this.adduser).subscribe(function (info) {
            console.log(info);
        }, function (error) {
            console.log(error);
        }, function () {
            _this.users.push(_this.adduser);
        });
    };
    HomeComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.userservice.find().subscribe(function (info) {
            var users = _this.users;
            info.forEach(function (item, index) {
                var x = new user_model_1.User(item.FirstName, item.LastName, item.Email);
                users.push(x);
            });
        }, function (error) {
            console.log(error);
        }, function () {
        });
    };
    HomeComponent.prototype.validateEmail = function (email) {
        var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        if (!filter.test(email)) {
            this.validEmail = false;
        }
        else {
            this.validEmail = true;
            this.usedemail(email);
        }
    };
    HomeComponent.prototype.usedemail = function (email) {
        var flag;
        this.users.forEach(function (item, index) {
            if (email == item.Email) {
                flag = true;
            }
        });
        if (flag) {
            this.used = true;
        }
        else {
            this.used = false;
        }
    };
    HomeComponent.prototype.toggleList = function () {
        this.show = (!this.show);
    };
    HomeComponent = __decorate([
        core_1.Component({
            templateUrl: 'app.template.html',
            providers: [user_service_1.UserService]
        }), 
        __metadata('design:paramtypes', [user_service_1.UserService])
    ], HomeComponent);
    return HomeComponent;
}());
exports.HomeComponent = HomeComponent;

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhvbWUuY29tcG9uZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7QUFBQSxxQkFBMEIsZUFBZSxDQUFDLENBQUE7QUFDMUMsMkJBQW1CLGNBQWMsQ0FBQyxDQUFBO0FBR2xDLDZCQUEwQixnQkFBZ0IsQ0FBQyxDQUFBO0FBTzNDO0lBTUksdUJBQW9CLFdBQXVCO1FBQXZCLGdCQUFXLEdBQVgsV0FBVyxDQUFZO1FBTDNDLFVBQUssR0FBUSxFQUFFLENBQUM7UUFDaEIsWUFBTyxHQUFNLElBQUksaUJBQUksQ0FBQyxJQUFJLEVBQUMsSUFBSSxFQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3RDLGVBQVUsR0FBQyxJQUFJLENBQUM7UUFDaEIsU0FBSSxHQUFDLEtBQUssQ0FBQztRQUNYLFNBQUksR0FBQyxLQUFLLENBQUM7SUFHWCxDQUFDO0lBQ0QsZ0NBQVEsR0FBUjtRQUFBLGlCQVVDO1FBVEcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7WUFDMUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUN0QixDQUFDLEVBQ0csVUFBQSxLQUFLO1lBQ0wsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUN2QixDQUFDLEVBQ0Q7WUFDSSxLQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxLQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDbEMsQ0FBQyxDQUFDLENBQUM7SUFDWCxDQUFDO0lBQ0QsZ0NBQVEsR0FBUjtRQUFBLGlCQWdCQztRQWZHLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxFQUFFLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTtZQUM5QixJQUFJLEtBQUssR0FBQyxLQUFJLENBQUMsS0FBSyxDQUFDO1lBQ3JCLElBQUksQ0FBQyxPQUFPLENBQUMsVUFBUyxJQUFJLEVBQUMsS0FBSztnQkFDNUIsSUFBSSxDQUFDLEdBQUMsSUFBSSxpQkFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUMsSUFBSSxDQUFDLFFBQVEsRUFBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQ3hELEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDbEIsQ0FBQyxDQUFDLENBQUM7UUFDUCxDQUFDLEVBQ0csVUFBQSxLQUFLO1lBQ0wsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUN2QixDQUFDLEVBQ0Q7UUFFQSxDQUFDLENBQUMsQ0FBQztJQUdYLENBQUM7SUFDRCxxQ0FBYSxHQUFiLFVBQWMsS0FBSztRQUNmLElBQUksTUFBTSxHQUFHLGlFQUFpRSxDQUFDO1FBRS9FLEVBQUUsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDdEIsSUFBSSxDQUFDLFVBQVUsR0FBQyxLQUFLLENBQUM7UUFDMUIsQ0FBQztRQUFBLElBQUksQ0FBQyxDQUFDO1lBQ0gsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUM7WUFDdkIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUMxQixDQUFDO0lBQ0wsQ0FBQztJQUNELGlDQUFTLEdBQVQsVUFBVSxLQUFLO1FBQ1gsSUFBSSxJQUFJLENBQUM7UUFDVCxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxVQUFTLElBQUksRUFBQyxLQUFLO1lBRWxDLEVBQUUsQ0FBQSxDQUFDLEtBQUssSUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUEsQ0FBQztnQkFDbEIsSUFBSSxHQUFDLElBQUksQ0FBQztZQUVkLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztRQUNILEVBQUUsQ0FBQSxDQUFDLElBQUksQ0FBQyxDQUFBLENBQUM7WUFDTCxJQUFJLENBQUMsSUFBSSxHQUFDLElBQUksQ0FBQztRQUNuQixDQUFDO1FBQUEsSUFBSSxDQUFBLENBQUM7WUFDRixJQUFJLENBQUMsSUFBSSxHQUFDLEtBQUssQ0FBQztRQUNwQixDQUFDO0lBRUwsQ0FBQztJQUNELGtDQUFVLEdBQVY7UUFDSSxJQUFJLENBQUMsSUFBSSxHQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDM0IsQ0FBQztJQXJFTDtRQUFDLGdCQUFTLENBQUM7WUFDUCxXQUFXLEVBQUUsbUJBQW1CO1lBQ2hDLFNBQVMsRUFBQyxDQUFDLDBCQUFXLENBQUM7U0FDMUIsQ0FBQzs7cUJBQUE7SUFtRUYsb0JBQUM7QUFBRCxDQWxFQSxBQWtFQyxJQUFBO0FBbEVZLHFCQUFhLGdCQWtFekIsQ0FBQSIsImZpbGUiOiJhc3NldHMvYXBwL2hvbWUuY29tcG9uZW50LmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7VXNlcn0gZnJvbSAnLi91c2VyLm1vZGVsJztcclxuaW1wb3J0IHtPbkluaXR9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQge0NvbnRyb2xHcm91cH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcclxuaW1wb3J0IHtVc2VyU2VydmljZX0gZnJvbSAnLi91c2VyLnNlcnZpY2UnO1xyXG5pbXBvcnQge0F1dGhTZXJ2aWNlfSBmcm9tICcuL2F1dGguc2VydmljZSc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHRlbXBsYXRlVXJsOiAnYXBwLnRlbXBsYXRlLmh0bWwnLFxyXG4gICAgcHJvdmlkZXJzOltVc2VyU2VydmljZV1cclxufSlcclxuZXhwb3J0IGNsYXNzIEhvbWVDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXR7XHJcbiAgICB1c2VyczpVc2VyW109W107XHJcbiAgICBhZGR1c2VyOlVzZXI9bmV3IFVzZXIobnVsbCxudWxsLG51bGwpO1xyXG4gICAgdmFsaWRFbWFpbD10cnVlO1xyXG4gICAgdXNlZD1mYWxzZTtcclxuICAgIHNob3c9ZmFsc2U7XHJcbiAgICBjb25zdHJ1Y3Rvcihwcml2YXRlIHVzZXJzZXJ2aWNlOlVzZXJTZXJ2aWNlKXtcclxuXHJcbiAgICB9XHJcbiAgICBvblN1Ym1pdCgpe1xyXG4gICAgICAgIHRoaXMudXNlcnNlcnZpY2Uuc2F2ZSh0aGlzLmFkZHVzZXIpLnN1YnNjcmliZShpbmZvPT4ge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coaW5mbyk7XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICBlcnJvcj0+IHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgKCk9PntcclxuICAgICAgICAgICAgICAgIHRoaXMudXNlcnMucHVzaCh0aGlzLmFkZHVzZXIpO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgIH1cclxuICAgIG5nT25Jbml0KCl7XHJcbiAgICAgICAgdGhpcy51c2Vyc2VydmljZS5maW5kKCkuc3Vic2NyaWJlKGluZm89PiB7XHJcbiAgICAgICAgICAgICAgICB2YXIgdXNlcnM9dGhpcy51c2VycztcclxuICAgICAgICAgICAgICAgIGluZm8uZm9yRWFjaChmdW5jdGlvbihpdGVtLGluZGV4KXtcclxuICAgICAgICAgICAgICAgICAgICB2YXIgeD1uZXcgVXNlcihpdGVtLkZpcnN0TmFtZSxpdGVtLkxhc3ROYW1lLGl0ZW0uRW1haWwpO1xyXG4gICAgICAgICAgICAgICAgICAgIHVzZXJzLnB1c2goeCk7XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIGVycm9yPT4ge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAoKT0+e1xyXG5cclxuICAgICAgICAgICAgfSk7XHJcblxyXG5cclxuICAgIH1cclxuICAgIHZhbGlkYXRlRW1haWwoZW1haWwpe1xyXG4gICAgICAgIHZhciBmaWx0ZXIgPSAvXihbYS16QS1aMC05X1xcLlxcLV0pK1xcQCgoW2EtekEtWjAtOVxcLV0pK1xcLikrKFthLXpBLVowLTldezIsNH0pKyQvO1xyXG5cclxuICAgICAgICBpZiAoIWZpbHRlci50ZXN0KGVtYWlsKSkge1xyXG4gICAgICAgICAgICB0aGlzLnZhbGlkRW1haWw9ZmFsc2U7XHJcbiAgICAgICAgfWVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLnZhbGlkRW1haWwgPSB0cnVlO1xyXG4gICAgICAgICAgICB0aGlzLnVzZWRlbWFpbChlbWFpbCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgdXNlZGVtYWlsKGVtYWlsKXtcclxuICAgICAgICB2YXIgZmxhZztcclxuICAgICAgICB0aGlzLnVzZXJzLmZvckVhY2goZnVuY3Rpb24oaXRlbSxpbmRleCl7XHJcblxyXG4gICAgICAgICAgICBpZihlbWFpbD09aXRlbS5FbWFpbCl7XHJcbiAgICAgICAgICAgICAgICBmbGFnPXRydWU7XHJcblxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgaWYoZmxhZyl7XHJcbiAgICAgICAgICAgIHRoaXMudXNlZD10cnVlO1xyXG4gICAgICAgIH1lbHNle1xyXG4gICAgICAgICAgICB0aGlzLnVzZWQ9ZmFsc2U7XHJcbiAgICAgICAgfVxyXG5cclxuICAgIH1cclxuICAgIHRvZ2dsZUxpc3QoKXtcclxuICAgICAgICB0aGlzLnNob3c9KCF0aGlzLnNob3cpO1xyXG4gICAgfVxyXG59Il0sInNvdXJjZVJvb3QiOiIvc291cmNlLyJ9
