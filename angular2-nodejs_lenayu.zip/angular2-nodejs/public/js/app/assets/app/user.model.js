"use strict";
var User = (function () {
    function User(FirstName, LastName, Email) {
        this.FirstName = FirstName;
        this.LastName = LastName;
        this.Email = Email;
    }
    return User;
}());
exports.User = User;

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInVzZXIubW9kZWwudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBO0lBQ0ksY0FBbUIsU0FBZ0IsRUFBUSxRQUFlLEVBQVEsS0FBWTtRQUEzRCxjQUFTLEdBQVQsU0FBUyxDQUFPO1FBQVEsYUFBUSxHQUFSLFFBQVEsQ0FBTztRQUFRLFVBQUssR0FBTCxLQUFLLENBQU87SUFBRSxDQUFDO0lBQ3JGLFdBQUM7QUFBRCxDQUZBLEFBRUMsSUFBQTtBQUZZLFlBQUksT0FFaEIsQ0FBQSIsImZpbGUiOiJhc3NldHMvYXBwL3VzZXIubW9kZWwuanMiLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgY2xhc3MgVXNlcntcclxuICAgIGNvbnN0cnVjdG9yKHB1YmxpYyBGaXJzdE5hbWU6c3RyaW5nLHB1YmxpYyBMYXN0TmFtZTpzdHJpbmcscHVibGljIEVtYWlsOnN0cmluZyl7fVxyXG59Il0sInNvdXJjZVJvb3QiOiIvc291cmNlLyJ9
