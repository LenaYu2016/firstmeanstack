"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var user_model_1 = require('./user.model');
var user_service_1 = require('./user.service');
var HomeComponent = (function () {
    function HomeComponent(userservice) {
        this.userservice = userservice;
        this.users = [];
        this.adduser = new user_model_1.User(null, null, null);
        this.validEmail = true;
        this.used = false;
        this.show = false;
    }
    HomeComponent.prototype.onSubmit = function () {
        var _this = this;
        this.userservice.save(this.adduser).subscribe(function (info) {
            console.log(info);
        }, function (error) {
            console.log(error);
        }, function () {
            _this.users.push(_this.adduser);
        });
    };
    HomeComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.userservice.find().subscribe(function (info) {
            var users = _this.users;
            info.forEach(function (item, index) {
                var x = new user_model_1.User(item.FirstName, item.LastName, item.Email);
                users.push(x);
            });
        }, function (error) {
            console.log(error);
        }, function () {
        });
    };
    HomeComponent.prototype.validateEmail = function (email) {
        var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        if (!filter.test(email)) {
            this.validEmail = false;
        }
        else {
            this.validEmail = true;
            this.usedemail(email);
        }
    };
    HomeComponent.prototype.usedemail = function (email) {
        var flag;
        this.users.forEach(function (item, index) {
            if (email == item.Email) {
                flag = true;
            }
        });
        if (flag) {
            this.used = true;
        }
        else {
            this.used = false;
        }
    };
    HomeComponent.prototype.toggleList = function () {
        this.show = (!this.show);
    };
    HomeComponent = __decorate([
        core_1.Component({
            templateUrl: 'app.template.html',
            providers: [user_service_1.UserService]
        }), 
        __metadata('design:paramtypes', [user_service_1.UserService])
    ], HomeComponent);
    return HomeComponent;
}());
exports.HomeComponent = HomeComponent;

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhvbWUuY29tcG9uZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7QUFBQSxxQkFBMEIsZUFBZSxDQUFDLENBQUE7QUFDMUMsMkJBQW1CLGNBQWMsQ0FBQyxDQUFBO0FBR2xDLDZCQUEwQixnQkFBZ0IsQ0FBQyxDQUFBO0FBTzNDO0lBTUksdUJBQW9CLFdBQXVCO1FBQXZCLGdCQUFXLEdBQVgsV0FBVyxDQUFZO1FBTDNDLFVBQUssR0FBUSxFQUFFLENBQUM7UUFDaEIsWUFBTyxHQUFNLElBQUksaUJBQUksQ0FBQyxJQUFJLEVBQUMsSUFBSSxFQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3RDLGVBQVUsR0FBQyxJQUFJLENBQUM7UUFDaEIsU0FBSSxHQUFDLEtBQUssQ0FBQztRQUNYLFNBQUksR0FBQyxLQUFLLENBQUM7SUFHWCxDQUFDO0lBQ0QsZ0NBQVEsR0FBUjtRQUFBLGlCQVVDO1FBVEcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLElBQUk7WUFDMUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUN0QixDQUFDLEVBQ0csVUFBQSxLQUFLO1lBQ0wsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUN2QixDQUFDLEVBQ0Q7WUFDSSxLQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxLQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDbEMsQ0FBQyxDQUFDLENBQUM7SUFDWCxDQUFDO0lBQ0QsZ0NBQVEsR0FBUjtRQUFBLGlCQWdCQztRQWZHLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxFQUFFLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTtZQUM5QixJQUFJLEtBQUssR0FBQyxLQUFJLENBQUMsS0FBSyxDQUFDO1lBQ3JCLElBQUksQ0FBQyxPQUFPLENBQUMsVUFBUyxJQUFJLEVBQUMsS0FBSztnQkFDNUIsSUFBSSxDQUFDLEdBQUMsSUFBSSxpQkFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUMsSUFBSSxDQUFDLFFBQVEsRUFBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQ3hELEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDbEIsQ0FBQyxDQUFDLENBQUM7UUFDUCxDQUFDLEVBQ0csVUFBQSxLQUFLO1lBQ0wsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUN2QixDQUFDLEVBQ0Q7UUFFQSxDQUFDLENBQUMsQ0FBQztJQUdYLENBQUM7SUFDRCxxQ0FBYSxHQUFiLFVBQWMsS0FBSztRQUNmLElBQUksTUFBTSxHQUFHLGlFQUFpRSxDQUFDO1FBRS9FLEVBQUUsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDdEIsSUFBSSxDQUFDLFVBQVUsR0FBQyxLQUFLLENBQUM7UUFDMUIsQ0FBQztRQUFBLElBQUksQ0FBQyxDQUFDO1lBQ0gsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUM7WUFDdkIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUMxQixDQUFDO0lBQ0wsQ0FBQztJQUNELGlDQUFTLEdBQVQsVUFBVSxLQUFLO1FBQ1gsSUFBSSxJQUFJLENBQUM7UUFDVCxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxVQUFTLElBQUksRUFBQyxLQUFLO1lBRWxDLEVBQUUsQ0FBQSxDQUFDLEtBQUssSUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUEsQ0FBQztnQkFDbEIsSUFBSSxHQUFDLElBQUksQ0FBQztZQUVkLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztRQUNILEVBQUUsQ0FBQSxDQUFDLElBQUksQ0FBQyxDQUFBLENBQUM7WUFDTCxJQUFJLENBQUMsSUFBSSxHQUFDLElBQUksQ0FBQztRQUNuQixDQUFDO1FBQUEsSUFBSSxDQUFBLENBQUM7WUFDRixJQUFJLENBQUMsSUFBSSxHQUFDLEtBQUssQ0FBQztRQUNwQixDQUFDO0lBRUwsQ0FBQztJQUNELGtDQUFVLEdBQVY7UUFDSSxJQUFJLENBQUMsSUFBSSxHQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDM0IsQ0FBQztJQXJFTDtRQUFDLGdCQUFTLENBQUM7WUFDUCxXQUFXLEVBQUUsbUJBQW1CO1lBQ2hDLFNBQVMsRUFBQyxDQUFDLDBCQUFXLENBQUM7U0FDMUIsQ0FBQzs7cUJBQUE7SUFtRUYsb0JBQUM7QUFBRCxDQWxFQSxBQWtFQyxJQUFBO0FBbEVZLHFCQUFhLGdCQWtFekIsQ0FBQSIsImZpbGUiOiJob21lLmNvbXBvbmVudC5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQge1VzZXJ9IGZyb20gJy4vdXNlci5tb2RlbCc7XHJcbmltcG9ydCB7T25Jbml0fSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHtDb250cm9sR3JvdXB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbic7XHJcbmltcG9ydCB7VXNlclNlcnZpY2V9IGZyb20gJy4vdXNlci5zZXJ2aWNlJztcclxuaW1wb3J0IHtBdXRoU2VydmljZX0gZnJvbSAnLi9hdXRoLnNlcnZpY2UnO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgICB0ZW1wbGF0ZVVybDogJ2FwcC50ZW1wbGF0ZS5odG1sJyxcclxuICAgIHByb3ZpZGVyczpbVXNlclNlcnZpY2VdXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBIb21lQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0e1xyXG4gICAgdXNlcnM6VXNlcltdPVtdO1xyXG4gICAgYWRkdXNlcjpVc2VyPW5ldyBVc2VyKG51bGwsbnVsbCxudWxsKTtcclxuICAgIHZhbGlkRW1haWw9dHJ1ZTtcclxuICAgIHVzZWQ9ZmFsc2U7XHJcbiAgICBzaG93PWZhbHNlO1xyXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSB1c2Vyc2VydmljZTpVc2VyU2VydmljZSl7XHJcblxyXG4gICAgfVxyXG4gICAgb25TdWJtaXQoKXtcclxuICAgICAgICB0aGlzLnVzZXJzZXJ2aWNlLnNhdmUodGhpcy5hZGR1c2VyKS5zdWJzY3JpYmUoaW5mbz0+IHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGluZm8pO1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgZXJyb3I9PiB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICgpPT57XHJcbiAgICAgICAgICAgICAgICB0aGlzLnVzZXJzLnB1c2godGhpcy5hZGR1c2VyKTtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICB9XHJcbiAgICBuZ09uSW5pdCgpe1xyXG4gICAgICAgIHRoaXMudXNlcnNlcnZpY2UuZmluZCgpLnN1YnNjcmliZShpbmZvPT4ge1xyXG4gICAgICAgICAgICAgICAgdmFyIHVzZXJzPXRoaXMudXNlcnM7XHJcbiAgICAgICAgICAgICAgICBpbmZvLmZvckVhY2goZnVuY3Rpb24oaXRlbSxpbmRleCl7XHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIHg9bmV3IFVzZXIoaXRlbS5GaXJzdE5hbWUsaXRlbS5MYXN0TmFtZSxpdGVtLkVtYWlsKTtcclxuICAgICAgICAgICAgICAgICAgICB1c2Vycy5wdXNoKHgpO1xyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICBlcnJvcj0+IHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgKCk9PntcclxuXHJcbiAgICAgICAgICAgIH0pO1xyXG5cclxuXHJcbiAgICB9XHJcbiAgICB2YWxpZGF0ZUVtYWlsKGVtYWlsKXtcclxuICAgICAgICB2YXIgZmlsdGVyID0gL14oW2EtekEtWjAtOV9cXC5cXC1dKStcXEAoKFthLXpBLVowLTlcXC1dKStcXC4pKyhbYS16QS1aMC05XXsyLDR9KSskLztcclxuXHJcbiAgICAgICAgaWYgKCFmaWx0ZXIudGVzdChlbWFpbCkpIHtcclxuICAgICAgICAgICAgdGhpcy52YWxpZEVtYWlsPWZhbHNlO1xyXG4gICAgICAgIH1lbHNlIHtcclxuICAgICAgICAgICAgdGhpcy52YWxpZEVtYWlsID0gdHJ1ZTtcclxuICAgICAgICAgICAgdGhpcy51c2VkZW1haWwoZW1haWwpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIHVzZWRlbWFpbChlbWFpbCl7XHJcbiAgICAgICAgdmFyIGZsYWc7XHJcbiAgICAgICAgdGhpcy51c2Vycy5mb3JFYWNoKGZ1bmN0aW9uKGl0ZW0saW5kZXgpe1xyXG5cclxuICAgICAgICAgICAgaWYoZW1haWw9PWl0ZW0uRW1haWwpe1xyXG4gICAgICAgICAgICAgICAgZmxhZz10cnVlO1xyXG5cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIGlmKGZsYWcpe1xyXG4gICAgICAgICAgICB0aGlzLnVzZWQ9dHJ1ZTtcclxuICAgICAgICB9ZWxzZXtcclxuICAgICAgICAgICAgdGhpcy51c2VkPWZhbHNlO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICB9XHJcbiAgICB0b2dnbGVMaXN0KCl7XHJcbiAgICAgICAgdGhpcy5zaG93PSghdGhpcy5zaG93KTtcclxuICAgIH1cclxufSJdLCJzb3VyY2VSb290IjoiL3NvdXJjZS8ifQ==
