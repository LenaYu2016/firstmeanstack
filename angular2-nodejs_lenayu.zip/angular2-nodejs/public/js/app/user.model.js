"use strict";
var User = (function () {
    function User(FirstName, LastName, Email) {
        this.FirstName = FirstName;
        this.LastName = LastName;
        this.Email = Email;
    }
    return User;
}());
exports.User = User;

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInVzZXIubW9kZWwudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBO0lBQ0ksY0FBbUIsU0FBZ0IsRUFBUSxRQUFlLEVBQVEsS0FBWTtRQUEzRCxjQUFTLEdBQVQsU0FBUyxDQUFPO1FBQVEsYUFBUSxHQUFSLFFBQVEsQ0FBTztRQUFRLFVBQUssR0FBTCxLQUFLLENBQU87SUFBRSxDQUFDO0lBQ3JGLFdBQUM7QUFBRCxDQUZBLEFBRUMsSUFBQTtBQUZZLFlBQUksT0FFaEIsQ0FBQSIsImZpbGUiOiJ1c2VyLm1vZGVsLmpzIiwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGNsYXNzIFVzZXJ7XHJcbiAgICBjb25zdHJ1Y3RvcihwdWJsaWMgRmlyc3ROYW1lOnN0cmluZyxwdWJsaWMgTGFzdE5hbWU6c3RyaW5nLHB1YmxpYyBFbWFpbDpzdHJpbmcpe31cclxufSJdLCJzb3VyY2VSb290IjoiL3NvdXJjZS8ifQ==
