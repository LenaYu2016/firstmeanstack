var express = require('express');
var router = express.Router();
var User=require('../models/user');
var Mailgun = require('mailgun').Mailgun;
var Mailchimp = require('mailchimp-api-v3')
var mg = new Mailgun('key-57d69e87136399db3995f0848b07a2a3');
var mailchimp = new Mailchimp('f002802de58f0834254b33fa7d96aeea-us13');
router.get('/', function(req, res, next) {
    res.render('index');
});
router.post('/user', function(req, res, next) {
    console.log(req);

    var user=new User({FirstName:req.body.FirstName,LastName:req.body.LastName,Email:req.body.Email});
    user.save(function(err,result){
        if(err){
            return res.status(500).json({message:'Error while saving data!'});
        }
        return  res.status(201).json({message:user});
    });
    mg.sendText('475099436yu@gmail.com', [req.body.Email],
        'Congratulations',
        'Congratulation, '+req.body.FirstName+',you register successfully!',
        'noreply@gmail.com', {},
        function(err) {
            if (err) console.log('Oh noes: ' + err);
            else     console.log('Success');
        });
    mailchimp.post({
        path : '/lists/94498118e7/members',
        body:{email_address:req.body.Email,status:'subscribed'}
    }, function (err, result) {
        if (err) console.log('Subscribe fail.' + err);
        else     console.log('Success');
    });
});
router.get('/all', function(req, res, next) {



    User.find(function(err,result){
        if(err){
            return res.status(500).json({message:'Error while get data!'});
        }
        return  res.status(201).json(result);
    });

});



module.exports = router;
